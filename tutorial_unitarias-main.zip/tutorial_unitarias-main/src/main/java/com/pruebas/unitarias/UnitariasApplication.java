package com.pruebas.unitarias;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UnitariasApplication {

	public static void main(String[] args) {
		SpringApplication.run(UnitariasApplication.class, args);
	}

}
